# 光明之魂 1：Godot 逆向工作台（第一阶段）

这不是完整移植。当前交付包含 ROM 静态分析、候选图块提取、Godot 资源浏览器及独立编写的动作 RPG 测试场景。测试关卡、角色图形、敌人和数值使用占位实现，不是从原作恢复的玩法或资源。

## 打开与编辑

使用 Godot 4.3 或更新版本导入 `project.godot`，按 F6/F5 运行主场景/工程。已在 Godot 4.6.3 无界面模式通过功能测试。

- WASD/方向键移动；Space/J 攻击；Q 使用药水；R 重置。
- Tab 打开/关闭 ROM 图块浏览器，左侧选择块；预览为灰度 4bpp 解码，**不是已确认的原作图像**。
- F2 开启地图编辑，点击地面/墙体切换，F5 保存、F6 载入。运行窗口需有键盘焦点；Godot 编辑器也使用 F5/F6 启动命令。
- 运行时保存的地图在 Godot `user://edited_map.json`，不修改工程数据。修改 `data/prototype.json` 可持久编辑初始地图、移动速度和战斗数值。
- `scenes/player.tscn`、`scripts/player.gd`：玩家；`scripts/main.gd`：工作台、关卡、敌人和编辑器。

## 已验证事实

ROM：8,388,608 字节，标题 SHINING SOUL，代码 AHUJ，厂商 8P，版本 0，头部校验通过。
SHA-256：04489e661a493d4f5ef7e0a3e91e3c30094cbf4286cf2b6eee63479b4c3721ce。
AHUJ 提示日版，不足以确定是否汉化或修改。检测到 FLASH_V126 字符串，不代表已还原存档格式。

`analysis/rom_report.json` 和 `data/rom_manifest.json` 保存偏移、解压长度、哈希、候选指针引用和限制。
检测出 169 个结构上能通过解压检查、输出不短于输入的 LZ77 候选，已导出 `.bin` 和 `.png`。这些候选**不一定是图像**，也可能是字库、地图、表格或假阳性。仅扫描 4 字节对齐的 0x10 型数据、跳过已覆盖区间，因此不保证完整。
`raw4bpp_*.png` 是指定 ROM 区间的原始图块解释，未确认其用途。
所有预览均使用索引灰度，不包含经验证的原调色板或精灵拼接。

## 重新提取

Python 3 + Pillow：

```sh
python tools/extract_rom.py /path/to/光明之魂1.gba --out .
```

原 ROM 不在交付压缩包内。工程运行不需要 ROM。生成工具只读输入 ROM，重新生成候选输出。

## 测试

```sh
godot --headless --path . --editor --import
godot --headless --path . -- --smoke-test
```

云沙箱请使用 `tools/run_godot.sh --headless -- --smoke-test`，将 Godot 用户数据放到可写目录。
测试验证实际场景加载、贴图加载、碰撞、攻击、经验和受伤。没有验证原作行为一致性。
REA 的 `inspect-artifact` 对此文件报告 unsupported binary format，原始输出保存在 `analysis/rea-artifact.json`。没有声称 REA 自动反编译了 GBA 程序。

## 下一阶段

1. 用支持 GBA 的调试器建立可重复的启动/场景状态，记录 VRAM、OAM、调色板和 DMA 来源。
2. 对照 ROM 地址确认压缩块用途和可能的自定义资源头，恢复原始色彩、拼接和动画；不同 4bpp/8bpp/位图/地图格式必须分别验证。
3. 恢复地图索引、碰撞、事件、物品/职业/敌人数值；不能以占位值冒充原数据。
4. 追踪 ARM/Thumb 游戏循环和存档布局，为战斗/AI/任务建立对照样例后逐步移植。
5. 音乐、剧情、完整地图、联机和存档兼容性尚未实现。

请勿将此工作台视为“完整光明之魂 Godot 版”，也不要将输出资产的用途或正确性作未经验证的推断。
